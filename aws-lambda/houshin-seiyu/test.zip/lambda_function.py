def lambda_handler(event, context):
	import json
	f = open('seiyu.json')
	data = json.load(f)
	f.close()

	if event is not None:
		if event['title'] == 'houshin':
			for i in data["houshin"]:
				print (i["character"])
				print("<a href='https://ja.wikipedia.org/wiki/" + i["voice"] + "'>")
				print(i["voice"])
				print("</a>¥n")
			ret = "hakyu houshin-engi"
		else:
			ret = "other title"
	else:
		ret = 'non title'

	return ret